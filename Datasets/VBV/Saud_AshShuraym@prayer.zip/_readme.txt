This is the timings file for the VerseByVerse Quran Project (http://www.versebyversequran.com/)

This is for Saud Ash Shuraym, Downloaded from (http://hidayahonline.org/?page=audio&reciter=9)
Sa`ood bin Ibraaheem Ash-Shuraym

To split these files, you need to use mp3splt

These files include the timings in milliseconds where each verse starts for a particular recitor.  
You can use them to split the Quran yourself if you have the original files or possibly the same recitor with higher quality or lower quality files than the ones we have.

Keep in mind a single reciter (qari) may have multiple recitations and if you use this on the wrong audio set, the timings will be wrong

Brought to you by Light Upon Light (http://www.lightuponlight.com/)

---------------------------------------------------------------------------------------------------------------------------------------------
Licensed by Creative Commons Attribution 3.0 License (http://creativecommons.org/licenses/by/3.0/)

